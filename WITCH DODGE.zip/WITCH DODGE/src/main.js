import { MainMenu } from './scenes/MainMenu.js';
import { GameScene } from './scenes/GameScene.js';
import { EndScreen } from './scenes/EndScreen.js';

const config = {
  type: Phaser.AUTO,
  width: 1280,
  height: 720,
  parent: 'game-container',
  backgroundColor: '#000000',
  pixelArt: false,
  scale: {
    mode: Phaser.Scale.FIT,
    autoCenter: Phaser.Scale.CENTER_BOTH
  },
  physics: {
    default: 'arcade',
    arcade: {
      gravity: { y: 0 },
      debug: false,
      checkCollision: {
        up: true,
        down: true,
        left: true,
        right: true
      },
      width: 1280,
      height: 720
    }
  },
  // Load all three scenes
  scene: [MainMenu, GameScene, EndScreen]
};

const game = new Phaser.Game(config);