export class MainMenu extends Phaser.Scene {

  constructor() {
    super('MainMenu');
  }

  preload() {
    // Load the background and the new heading image
    this.load.image('background', 'assets/background.jpg');
    this.load.image('titleImage', 'assets/heading.png'); // <-- Loads your heading
  }

  create() {
    this.add.image(0, 0, 'background').setOrigin(0, 0).setDisplaySize(this.sys.game.config.width, this.sys.game.config.height);

    // --- CHANGED: Display the heading image instead of text ---
    // The old text line was removed.
    const title = this.add.image(
      this.sys.game.config.width / 2,
      this.sys.game.config.height / 2 - 100,
      'titleImage' // Use the key for your loaded image
    );
    title.setScale(2.0); // Adjust this number to change the size of your heading
    // ----------------------------------------------------

    const startButton = this.add.text(
      this.sys.game.config.width / 2,
      this.sys.game.config.height / 2 + 50,
      'GAME START',
      { fontSize: '78px', fill: 'white', fontWeight: 'bold' }
    ).setOrigin(0.5);

    startButton.setInteractive();

    startButton.on('pointerdown', () => {
      this.scene.start('GameScene');
    });
  }
}