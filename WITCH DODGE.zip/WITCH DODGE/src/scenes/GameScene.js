export class GameScene extends Phaser.Scene {

  constructor() {
    super('GameScene');
    this.player = null;
    this.enemy = null;
    this.cursors = null;
    this.witchHealth = 5;
    this.hearts = null;
    this.isGameOver = false;
    this.cackleSound = null;
  }

  preload() {
    this.load.image('player', 'assets/hat.png');
    this.load.image('enemy', 'assets/witch.png');
    this.load.image('background', 'assets/background.jpg');
    this.load.image('heart', 'assets/heart.png');
    this.load.audio('witchCackle', 'assets/witch-laugh-401713.mp3');
  }

  create() {
    // Reset game state on each start
    this.isGameOver = false;
    this.witchHealth = 5;

    // Create background
    this.background = this.add.image(0, 0, 'background');
    this.background.setOrigin(0, 0);
    this.background.setDisplaySize(this.sys.game.config.width, this.sys.game.config.height);
    
    // --- Generate random starting positions ---
    const gameWidth = this.sys.game.config.width;
    const gameHeight = this.sys.game.config.height;
    const randomPlayerX = Phaser.Math.Between(100, gameWidth - 100);
    const randomPlayerY = Phaser.Math.Between(100, gameHeight - 100);
    const randomEnemyX = Phaser.Math.Between(100, gameWidth - 100);
    const randomEnemyY = Phaser.Math.Between(100, gameHeight - 100);
    
    // Create player and enemy at random positions
    this.player = this.physics.add.sprite(randomPlayerX, randomPlayerY, 'player');
    this.enemy = this.physics.add.sprite(randomEnemyX, randomEnemyY, 'enemy');

    // Setup player
    this.player.setCollideWorldBounds(true);
    this.player.setScale(0.65);
    this.player.body.setSize(120, 130);

    // Setup enemy
    this.enemy.setScale(0.4);
    this.enemy.setCollideWorldBounds(true);
    this.enemy.body.setSize(170, 300); 

    // Setup controls and physics
    this.cursors = this.input.keyboard.createCursorKeys();
    this.physics.add.overlap(this.player, this.enemy, this.gameOver, null, this);

    // Setup hearts display
    this.hearts = this.add.group({ key: 'heart', repeat: 4, setXY: { x: 120, y: 40, stepX: 40 } });
    this.hearts.children.iterate(heart => heart.setScale(0.13));

    // Setup health decay timer
    this.time.addEvent({ delay: 2400, callback: this.decreaseWitchHealth, callbackScope: this, loop: true });
    
    // Setup repeating sound
    this.cackleSound = this.sound.add('witchCackle');
    this.cackleSound.on('complete', () => { this.time.delayedCall(2000, this.playCackle, [], this); });
    this.playCackle();
  }
  
  playCackle() { if (!this.isGameOver && this.cackleSound) { this.cackleSound.play(); } }
  
  decreaseWitchHealth() {
    if (this.isGameOver || this.witchHealth <= 0) return;
    this.witchHealth -= 1;
    const heartToHide = this.hearts.getChildren()[this.witchHealth];
    if (heartToHide) {
      heartToHide.visible = false;
    }
    if (this.witchHealth <= 0) {
      this.winGame();
    }
  }
  
  update() {
    if (this.isGameOver || !this.player.body) return;

    // Witch AI
    this.physics.moveToObject(this.enemy, this.player, 100);

    // Player controls
    if (this.cursors.left.isDown) {
      this.player.setVelocityX(-170);
    } else if (this.cursors.right.isDown) {
      this.player.setVelocityX(170);
    } else if (this.cursors.up.isDown) {
      this.player.setVelocityY(-170);
    } else if (this.cursors.down.isDown) {
      this.player.setVelocityY(170);
    } else {
      this.player.setVelocityX(0);
      this.player.setVelocityY(0);
    }
  }

  gameOver() { // Player loses
    if (this.isGameOver) return;
    this.isGameOver = true;
    this.physics.pause();
    if (this.cackleSound) {
        this.cackleSound.stop();
        this.sound.remove(this.cackleSound);
    }
    this.scene.start('EndScreen', { didPlayerWin: false });
  }

  winGame() { // Player wins
    if (this.isGameOver) return;
    this.isGameOver = true;
    this.physics.pause();
    if (this.cackleSound) {
        this.cackleSound.stop();
        this.sound.remove(this.cackleSound);
    }
    this.scene.start('EndScreen', { didPlayerWin: true });
  }
}
