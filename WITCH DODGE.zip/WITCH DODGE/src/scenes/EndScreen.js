export class EndScreen extends Phaser.Scene {

  constructor() {
    super('EndScreen');
  }
  
  init(data) {
    // Receive the result from the GameScene
    this.playerWon = data.didPlayerWin;
  }

  preload() {
    this.load.image('background', 'assets/background.jpg');
    this.load.image('witch', 'assets/witchat.png');
    
  }

  create() {
    this.add.image(0, 0, 'background').setOrigin(0, 0).setDisplaySize(this.sys.game.config.width, this.sys.game.config.height);

    // Display the witch image
    this.add.image(this.sys.game.config.width / 2, this.sys.game.config.height / 2 - 100, 'witch').setScale(0.5);

    let resultText = '';
    let resultColor = '';
    
    // Check if the player won or lost
    if (this.playerWon) {
      resultText = 'YOU WIN';
      resultColor = '#00ff00'; // Green
    } else {
      resultText = 'YOU LOSE';
      resultColor = '#ff0000'; // Red
    }
    
    // Display the result text
    this.add.text(
      this.sys.game.config.width / 2,
      this.sys.game.config.height / 2 + 100,
      resultText,
      { fontSize: '84px', fill: resultColor, fontStyle: 'bold' }
    ).setOrigin(0.5);

    // Add a "Click to Menu" message
    this.add.text(
      this.sys.game.config.width / 2,
      this.sys.game.config.height / 2 + 200,
      'Click to Return to Menu',
      { fontSize: '32px', fill: '#fff' }
    ).setOrigin(0.5);
    
    // Listen for a click to go back to the MainMenu
    this.input.on('pointerdown', () => {
      this.scene.start('MainMenu');
    });
  }
}